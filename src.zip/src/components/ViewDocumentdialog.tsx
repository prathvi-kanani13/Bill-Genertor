import React, { useState, useEffect } from 'react';
import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    List,
    ListItemButton,
    ListItemText,
    Typography
} from '@mui/material';

interface ViewDocumentDialogProps {
    open: boolean;
    onClose: () => void;
    documentFiles: { name: string; url: string; type: "sales" | "voucher" }[];
}

const ViewDocumentDialog: React.FC<ViewDocumentDialogProps> = ({
    open,
    onClose,
    documentFiles
}) => {
    const [selectedFile, setSelectedFile] = useState<{
        name: string;
        url: string;
        type: "sales" | "voucher";
    } | null>(null);

    useEffect(() => {
        if (documentFiles.length > 0) {
            setSelectedFile(documentFiles[0]);
        } else {
            setSelectedFile(null);
        }
    }, [documentFiles, open]);

    return (
        <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
            <DialogTitle>View Uploaded Documents</DialogTitle>
            <DialogContent>
                {documentFiles.length === 0 ? (
                    <Typography>No documents available.</Typography>
                ) : (
                    <>
                        {documentFiles.length > 1 && (
                            <>
                                <Typography sx={{ mb: 1 }}>Select a document to view:</Typography>
                                <List dense>
                                    {documentFiles.map((file, idx) => (
                                        <ListItemButton
                                            key={idx}
                                            onClick={() => setSelectedFile(file)}
                                            selected={selectedFile?.name === file.name}
                                        >
                                            <ListItemText
                                                primary={file.name}
                                                secondary={`Type: ${file.type === "sales" ? "Sales" : "Voucher"}`}
                                            />
                                        </ListItemButton>
                                    ))}
                                </List>
                            </>
                        )}

                        {selectedFile && (
                            <>
                                <Typography sx={{ fontWeight: "bold", mt: 2 }}>
                                    {selectedFile.name}
                                </Typography>
                                <Typography sx={{ mb: 1 }}>
                                    Type: {selectedFile.type === "sales" ? "Sales" : "Voucher"}
                                </Typography>
                                <embed
                                    src={selectedFile.url}
                                    title={selectedFile.name}
                                    style={{
                                        width: "100%",
                                        height: "75vh",
                                        border: "1px solid #ccc",
                                        marginTop: "0.5rem"
                                    }}
                                />
                            </>
                        )}
                    </>
                )}
            </DialogContent>
            <DialogActions>
                <Button
                    onClick={onClose}
                    variant="contained"
                    sx={{ bgcolor: "#3f51b5", "&:hover": { bgcolor: "#303f9f" } }}
                >
                    Close
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default ViewDocumentDialog;